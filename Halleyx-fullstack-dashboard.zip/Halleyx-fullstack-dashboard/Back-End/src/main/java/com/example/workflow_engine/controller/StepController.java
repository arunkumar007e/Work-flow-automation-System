package com.example.workflow_engine.controller;

import com.example.workflow_engine.entity.Step;
import com.example.workflow_engine.entity.Workflow;
import com.example.workflow_engine.repository.StepRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/steps")
@CrossOrigin(origins = "*")
public class StepController {

    @Autowired
    private StepRepository stepRepository;

    // Workflow ID-ah fetch panni Step-kooda link panrom
    @PostMapping("/workflow/{workflowId}")
    public ResponseEntity<Step> createStep(@PathVariable String workflowId, @RequestBody Step step) {

        // 1. Oru temporary Workflow object create panni adhu kula ID-ah vekurom
        Workflow tempWorkflow = new Workflow();
        tempWorkflow.setId(workflowId);

        // 2. Step entity-la namma 'setWorkflow' dhaan vechurukom (setWorkflowId illa)
        step.setWorkflow(tempWorkflow);

        // stepOrder null-ah vandha automatic-ah 1 nu set panrom
        if (step.getStepOrder() == null) {
            step.setStepOrder(1);
        }

        return ResponseEntity.ok(stepRepository.save(step));
    }

    // Workflow ID vechi steps-ah fetch panrom
    @GetMapping("/workflow/{workflowId}")
    public ResponseEntity<List<Step>> getStepsByWorkflow(@PathVariable String workflowId) {
        return ResponseEntity.ok(stepRepository.findByWorkflowIdOrderByStepOrderAsc(workflowId));
    }
}