package com.example.workflow_engine.controller;

import com.example.workflow_engine.entity.*;
import com.example.workflow_engine.repository.*;
import org.mvel2.MVEL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/workflows")
@CrossOrigin(origins = "*")
public class WorkflowController {

    @Autowired private WorkflowRepository workflowRepo;
    @Autowired private StepRepository stepRepo;

    @GetMapping
    public List<Workflow> getAll() { return workflowRepo.findAll(); }

    @PostMapping
    public ResponseEntity<Workflow> createWorkflow(@RequestBody Workflow workflow) {
        if (workflow.getVersion() == null) workflow.setVersion(1);
        if (workflow.getActive() == null) workflow.setActive(true);
        return ResponseEntity.ok(workflowRepo.save(workflow));
    }

    @PostMapping("/{id}/execute")
    public ResponseEntity<String> execute(@PathVariable String id, @RequestBody Map<String, Object> input) {
        Workflow wf = workflowRepo.findById(id).orElse(null);
        if (wf == null) return ResponseEntity.badRequest().body("Workflow not found");

        List<Step> steps = stepRepo.findByWorkflowIdOrderByStepOrderAsc(id);
        if (steps == null || steps.isEmpty()) {
            return ResponseEntity.ok("--- ENGINE LOG ---\nNo steps found for: " + wf.getName());
        }

        StringBuilder logs = new StringBuilder("--- ENGINE LOG ---\n");
        Step currentStep = steps.get(0);
        Set<Long> visitedSteps = new HashSet<>();

        while (currentStep != null && !visitedSteps.contains(currentStep.getId())) {
            visitedSteps.add(currentStep.getId());
            logs.append("Step: ").append(currentStep.getName()).append("\n");

            Step nextStep = null;
            boolean ruleMatched = false;

            if (currentStep.getRules() != null && !currentStep.getRules().isEmpty()) {
                List<Rule> rules = new ArrayList<>(currentStep.getRules());
                rules.sort(Comparator.comparingInt(Rule::getPriority));

                for (Rule rule : rules) {
                    try {
                        String expression = rule.getExpression();
                        boolean isTruePath = (expression == null || expression.isEmpty() || expression.equalsIgnoreCase("true"));

                        Boolean matched = isTruePath ? true : (Boolean) MVEL.eval(expression, input);

                        if (matched != null && matched) {
                            // --- PROFESSIONAL LOG TRANSFORMATION ---
                            String professionalMessage = expression;
                            if (expression != null) {
                                if (expression.contains("amount > 500")) {
                                    professionalMessage = "CEO review required";
                                } else if (expression.contains("days > 3")) {
                                    professionalMessage = "Leave duration exceeds 3 days (Special approval required)";
                                } else if (isTruePath) {
                                    professionalMessage = "Standard process validation successful";
                                }
                            }

                            logs.append("Verification: ").append(professionalMessage).append("\n");
                            ruleMatched = true;

                            if (rule.getNextStepId() != null) {
                                nextStep = stepRepo.findById(rule.getNextStepId()).orElse(null);
                            }
                            break;
                        }
                    } catch (Exception e) {
                        logs.append("Logic Error: ").append(e.getMessage()).append("\n");
                    }
                }
            }

            if (!ruleMatched) logs.append("No more rules matched. Ending flow.\n");
            currentStep = nextStep;
        }

        logs.append("\n Finished.");
        return ResponseEntity.ok(logs.toString());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWorkflow(@PathVariable String id) {
        workflowRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}