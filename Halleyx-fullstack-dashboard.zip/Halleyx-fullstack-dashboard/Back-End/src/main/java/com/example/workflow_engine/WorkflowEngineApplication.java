package com.example.workflow_engine;//this line is defines a package of the javaclass

import org.springframework.boot.SpringApplication; // This imports the SpringApplication class from Spring Boot.
import org.springframework.boot.autoconfigure.SpringBootApplication; // This imports the SpringBootApplication annotation.

@SpringBootApplication // main Spring Boot application class
public class WorkflowEngineApplication { // This declares the main class of the application.

	public static void main(String[] args) {
		SpringApplication.run(WorkflowEngineApplication.class, args);
	}

}
