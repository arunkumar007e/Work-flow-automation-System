package com.example.workflow_engine.service;

import com.example.workflow_engine.entity.Rule;
import com.example.workflow_engine.entity.Step;
import com.example.workflow_engine.repository.RuleRepository;
import com.example.workflow_engine.repository.StepRepository;
import com.example.workflow_engine.repository.WorkflowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.expression.MapAccessor;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class WorkflowExecutionService {

    @Autowired
    private WorkflowRepository workflowRepository;

    @Autowired
    private StepRepository stepRepository;

    @Autowired
    private RuleRepository ruleRepository;

    public String executeWorkflow(String workflowId, Map<String, Object> inputData) {
        // 1. Workflow ID ippo String-ah dhaan irukku, adhu correct
        List<Step> steps = stepRepository.findByWorkflowIdOrderByStepOrderAsc(workflowId);
        if (steps.isEmpty()) {
            return "Error: Indha Workflow-ku steps yedhuvum illai!";
        }

        Step currentStep = steps.get(0);
        StringBuilder log = new StringBuilder("🚀 Workflow Execution Started...\n");

        int iterations = 0;
        while (currentStep != null && iterations < 10) {
            log.append("➡️ Current Step: ").append(currentStep.getName()).append("\n");

            // CHANGE 1: findByStepId ippo Long parameter ethirpaakum
            List<Rule> rules = ruleRepository.findByStepIdOrderByPriorityAsc(currentStep.getId());
            Long nextStepId = null;
            boolean ruleMatched = false;

            // 3. Rules-ah check pandrom
            for (Rule rule : rules) {
                // CHANGE 2: getConditionExpression-ku badhila getExpression()
                boolean result = evaluateCondition(rule.getExpression(), inputData);
                if (result) {
                    log.append("   ✅ Rule Matched: [").append(rule.getExpression()).append("]\n");
                    nextStepId = rule.getNextStepId(); // Ippo idhu Long
                    ruleMatched = true;
                    break;
                }
            }

            if (!ruleMatched) {
                log.append("   ❌ No rules matched! Workflow Stopped.\n");
                break;
            }

            if (nextStepId == null) {
                log.append("   🏁 Workflow Completed Successfully!\n");
                break;
            }

            // 4. Next step-ah kandupudikirom (Long comparison)
            Long finalNextStepId = nextStepId;
            currentStep = steps.stream()
                    .filter(s -> s.getId().equals(finalNextStepId))
                    .findFirst()
                    .orElse(null);

            iterations++;
        }

        return log.toString();
    }

    private boolean evaluateCondition(String condition, Map<String, Object> inputData) {
        try {
            ExpressionParser parser = new SpelExpressionParser();
            StandardEvaluationContext context = new StandardEvaluationContext(inputData);
            context.addPropertyAccessor(new MapAccessor());

            Boolean result = parser.parseExpression(condition).getValue(context, Boolean.class);
            return result != null && result;
        } catch (Exception e) {
            System.out.println("Condition check pandradhula error: " + condition);
            return false;
        }
    }
}