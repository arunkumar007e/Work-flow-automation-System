package com.example.workflow_engine.repository;

import com.example.workflow_engine.entity.Rule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
// String-ku badhila 'Long' nu maathunga Arun
public interface RuleRepository extends JpaRepository<Rule, Long> {

    // Indha parameter-um 'Long' (Capital L) nu irukkuradhu best practice
    List<Rule> findByStepIdOrderByPriorityAsc(Long stepId);
}