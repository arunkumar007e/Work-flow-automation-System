package com.example.workflow_engine.controller;

import com.example.workflow_engine.entity.Rule;
import com.example.workflow_engine.entity.Step;
import com.example.workflow_engine.repository.RuleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rules")
@CrossOrigin(origins = "*")
public class RuleController {

    @Autowired
    private RuleRepository ruleRepository;

    // Frontend call: /api/rules/step/4
    @PostMapping("/step/{stepId}")
    public ResponseEntity<Rule> createRule(@PathVariable Long stepId, @RequestBody Rule rule) {

        // 1. Oru temporary Step object create panrom
        Step tempStep = new Step();
        tempStep.setId(stepId);

        // 2. Rule-kulla andha step object-ah set panrom (setStepId-ku badhula setStep)
        rule.setStep(tempStep);

        // 3. Priority null-ah irundha 1 set panrom
        if (rule.getPriority() == null || rule.getPriority() == 0) {
            rule.setPriority(1);
        }

        return ResponseEntity.ok(ruleRepository.save(rule));
    }

    @GetMapping("/step/{stepId}")
    public ResponseEntity<List<Rule>> getRulesByStep(@PathVariable Long stepId) {
        // Idhu unga repository-la stepId query-ah irukanum
        return ResponseEntity.ok(ruleRepository.findByStepIdOrderByPriorityAsc(stepId));
    }
}