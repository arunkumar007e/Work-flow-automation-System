package com.example.workflow_engine.repository;

import com.example.workflow_engine.entity.Step;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface StepRepository extends JpaRepository<Step, Long> {
    // Workflow ID vechi steps-ah fetch panna idhu kandippa venum
    List<Step> findByWorkflowIdOrderByStepOrderAsc(String workflowId);
}