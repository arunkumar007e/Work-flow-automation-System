import React, { useEffect, useState } from 'react';
import { Play as PlayIcon, Settings as SettingsIcon, Plus as PlusIcon, X as XIcon, ArrowRight as ArrowRightIcon, Trash2 as TrashIcon, CheckCircle2, AlertCircle, Calendar, Search, Terminal as TerminalIcon } from 'lucide-react';

function App() {
  const [workflows, setWorkflows] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [executionResult, setExecutionResult] = useState(null);
  const [executionStatus, setExecutionStatus] = useState(null);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isExecModalOpen, setIsExecModalOpen] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  
  const [newWorkflow, setNewWorkflow] = useState({ id: '', name: '', version: 1, active: true });
  
  // FIXED: Empty strings to prevent '0' from appearing automatically
  const [execInput, setExecInput] = useState({ days: '', amount: '', priority: 'Low' });
  const [activeWfId, setActiveWfId] = useState(null);

  const [steps, setSteps] = useState([]);
  const [newStepName, setNewStepName] = useState('');
  const [isRuleModalOpen, setIsRuleModalOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(null);
  const [ruleData, setRuleData] = useState({ expression: '', nextStepId: '', priority: 1 });

  const fetchWorkflows = () => {
    fetch('http://localhost:8080/api/workflows')
      .then(res => res.json())
      .then(data => setWorkflows(Array.isArray(data) ? data : []))
      .catch(err => console.error("Fetch Error:", err));
  };

  useEffect(() => { fetchWorkflows(); }, []);

  const handleCreateWorkflow = () => {
    if(!newWorkflow.id || !newWorkflow.name) return alert("ID and Name are required!");
    fetch('http://localhost:8080/api/workflows', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newWorkflow)
    }).then(() => {
      fetchWorkflows();
      setIsModalOpen(false);
      setNewWorkflow({ id: '', name: '', version: 1, active: true });
    });
  };

  const finalizeExecute = () => {
    const payload = {
        days: Number(execInput.days) || 0,
        amount: Number(execInput.amount) || 0,
        priority: execInput.priority
    };

    fetch(`http://localhost:8080/api/workflows/${activeWfId}/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload) 
    })
    .then(async (res) => {
      const text = await res.text();
      if (!res.ok) throw new Error(text || "Server Error");
      return text;
    })
    .then(log => {
      setExecutionResult(log);
      setExecutionStatus(log.includes("✅") ? "success" : "warning");
      setIsExecModalOpen(false);
    })
    .catch(err => {
      setExecutionResult("Execution Failed: " + err.message);
      setExecutionStatus("warning");
      setIsExecModalOpen(false);
    });
  };

  const openSettings = (workflow) => {
    setSelectedWorkflow(workflow);
    fetch(`http://localhost:8080/api/steps/workflow/${workflow.id}`)
      .then(res => res.json())
      .then(data => setSteps(Array.isArray(data) ? data : []));
  };

  const handleAddStep = () => {
    if(!newStepName) return;
    const stepData = { name: newStepName, stepOrder: steps.length + 1 };
    fetch(`http://localhost:8080/api/steps/workflow/${selectedWorkflow.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(stepData)
    })
    .then(res => res.json())
    .then(data => { 
      setSteps([...steps, data]); 
      setNewStepName(''); 
    });
  };

  const handleAddRule = () => {
    const finalRule = { 
      expression: ruleData.expression, 
      nextStepId: ruleData.nextStepId ? Number(ruleData.nextStepId) : null, 
      stepId: currentStep.id, 
      priority: 1 
    };
    fetch(`http://localhost:8080/api/rules/step/${currentStep.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(finalRule)
    }).then(() => { 
      alert("Logic Saved!"); 
      setIsRuleModalOpen(false); 
    });
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 p-8 font-sans">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4 border-b border-slate-800 pb-8">
          <div>
            <h1 className="text-4xl font-black text-emerald-400 italic tracking-tighter">HALLEYX ENGINE</h1>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-[0.2em] mt-1">Workflow List & Auditor</p>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
              <input 
                type="text" 
                placeholder="Search workflows..." 
                className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all text-sm"
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button onClick={() => setIsModalOpen(true)} className="bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-blue-900/20 active:scale-95 transition-all">
              <PlusIcon size={18} /> New Workflow
            </button>
          </div>
        </div>

        {/* Workflow Table */}
        <div className="bg-slate-900/40 border border-slate-800 rounded-[2rem] overflow-hidden backdrop-blur-md shadow-2xl">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 text-xs font-black uppercase tracking-widest">
                <th className="p-6 text-[10px]">ID</th>
                <th className="p-6">Name</th>
                <th className="p-6 text-center">Version</th>
                <th className="p-6 text-center text-[10px]">Status</th>
                <th className="p-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {workflows.filter(wf => wf.name.toLowerCase().includes(searchTerm.toLowerCase())).map(wf => (
                <tr key={wf.id} className="hover:bg-slate-800/30 transition-colors group">
                  <td className="p-6 font-mono text-xs text-slate-500">{wf.id}</td>
                  <td className="p-6 font-bold text-lg group-hover:text-emerald-400 transition-colors">{wf.name}</td>
                  <td className="p-6 text-center text-slate-400 text-sm font-mono">v{wf.version}</td>
                  <td className="p-6 text-center">
                    <span className="bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-[10px] font-black uppercase border border-emerald-500/20 tracking-tighter">Active</span>
                  </td>
                  <td className="p-6 text-right space-x-3">
                    <button onClick={() => {setActiveWfId(wf.id); setIsExecModalOpen(true);}} className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-4 py-2 rounded-lg text-xs font-black uppercase inline-flex items-center gap-2 transition-all active:scale-95 shadow-lg shadow-emerald-500/10">
                      <PlayIcon size={14} fill="currentColor"/> Execute
                    </button>
                    <button onClick={() => openSettings(wf)} className="bg-slate-800 hover:bg-slate-700 p-2 rounded-lg border border-slate-700 text-white transition-all">
                      <SettingsIcon size={18}/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 🚀 Terminal Pop-up Log Viewer */}
        {executionResult && (
          <div className="fixed inset-0 bg-black/90 z-[300] flex justify-center items-center p-6 backdrop-blur-md">
            <div className="bg-[#020617] border border-emerald-500/30 rounded-[2.5rem] w-full max-w-2xl shadow-[0_0_80px_rgba(16,185,129,0.15)] overflow-hidden">
              <div className="bg-slate-900/80 p-6 border-b border-slate-800 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <TerminalIcon size={20} className="text-emerald-400"/>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter">Execution Terminal</h3>
                </div>
                <button onClick={() => setExecutionResult(null)} className="p-2 hover:bg-red-500/20 hover:text-red-500 rounded-full text-slate-500 transition-all"><XIcon size={24}/></button>
              </div>
              <div className="p-8">
                <div className="bg-black/60 rounded-2xl border border-slate-800 p-6 font-mono text-sm leading-relaxed max-h-[400px] overflow-y-auto">
                  <div className="flex flex-col gap-2">
                    {executionResult.split('\n').map((line, i) => (
                      <div key={i} className={`${line.includes('✅') ? 'text-emerald-400 font-bold' : line.includes('📍') ? 'text-blue-400' : 'text-slate-400'}`}>
                        {line}
                      </div>
                    ))}
                  </div>
                </div>
                <button onClick={() => setExecutionResult(null)} className="w-full mt-6 bg-slate-800 text-white py-4 rounded-xl font-black uppercase text-[10px] tracking-widest border border-slate-700 transition-all active:scale-95">Close Session</button>
              </div>
            </div>
          </div>
        )}

        {/* Execution Input Modal */}
        {isExecModalOpen && (
          <div className="fixed inset-0 bg-black/95 z-[200] flex justify-center items-center p-4 backdrop-blur-xl">
            <div className="bg-[#0f172a] border border-slate-800 p-10 rounded-[3rem] w-full max-w-lg shadow-2xl">
              <h2 className="text-2xl font-black italic text-emerald-400 mb-8 uppercase tracking-tighter">Enter Input Data</h2>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase mb-2 block tracking-widest">Leave Days</label>
                    <input 
                        type="number" 
                        placeholder="Enter days" 
                        className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-emerald-500 transition-all" 
                        value={execInput.days} 
                        onChange={e => setExecInput({...execInput, days: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-slate-500 uppercase mb-2 block tracking-widest">Amount ($)</label>
                    <input 
                        type="number" 
                        placeholder="Enter Amount" 
                        className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-emerald-500 transition-all" 
                        value={execInput.amount} 
                        onChange={e => setExecInput({...execInput, amount: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase mb-2 block tracking-widest">Priority</label>
                  <select className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-emerald-500 transition-all" value={execInput.priority} onChange={e => setExecInput({...execInput, priority: e.target.value})}>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
                <button onClick={finalizeExecute} className="w-full bg-emerald-500 text-slate-950 py-4 rounded-2xl font-black text-lg hover:bg-emerald-400 shadow-xl shadow-emerald-900/20 transition-all active:scale-95">START EXECUTION</button>
                <button onClick={() => setIsExecModalOpen(false)} className="w-full text-slate-500 font-bold hover:text-white text-[10px] uppercase mt-2 tracking-widest text-center">Cancel</button>
              </div>
            </div>
          </div>
        )}

        {/* Sidebar Designer */}
        {selectedWorkflow && (
          <div className="fixed inset-0 z-[150] flex justify-end">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedWorkflow(null)}></div>
            <div className="relative w-full max-w-md bg-[#0f172a] border-l border-slate-800 p-8 overflow-y-auto shadow-2xl">
              <h2 className="text-2xl font-black text-emerald-400 mb-8 italic uppercase tracking-tighter">Workflow Editor</h2>
              <div className="space-y-4 mb-8">
                {steps.map((s, i) => (
                  <div key={s.id} onClick={() => {setCurrentStep(s); setIsRuleModalOpen(true);}} className="p-5 bg-slate-900/50 border border-slate-800 rounded-2xl hover:border-emerald-500 cursor-pointer flex justify-between items-center transition-all group">
                    <span className="font-bold text-slate-200">{i+1}. {s.name}</span>
                    <ArrowRightIcon size={14} className="text-slate-500 group-hover:translate-x-1 transition-all"/>
                  </div>
                ))}
              </div>
              <div className="bg-slate-950 p-6 rounded-3xl border border-dashed border-slate-800 text-center">
                <input type="text" placeholder="Step Name..." className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl mb-4 text-white outline-none" value={newStepName} onChange={(e) => setNewStepName(e.target.value)}/>
                <button onClick={handleAddStep} className="w-full bg-emerald-500 text-slate-950 py-3 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all">Add New Step</button>
              </div>
            </div>
          </div>
        )}

        {/* Rule Logic Modal */}
        {isRuleModalOpen && (
          <div className="fixed inset-0 bg-black/90 flex justify-center items-center z-[200] p-4 text-white">
            <div className="bg-[#0f172a] p-8 rounded-[2.5rem] w-full max-w-lg border border-slate-800 shadow-2xl">
              <h2 className="text-2xl font-black italic text-emerald-400 mb-8 uppercase tracking-tighter">LOGIC: {currentStep?.name}</h2>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase mb-2 block tracking-widest">Logic Expression (MVEL)</label>
                  <input type="text" placeholder="e.g., amount > 500" className="w-full bg-slate-950 border border-slate-800 p-5 rounded-2xl outline-none focus:border-emerald-500 text-white font-mono text-sm transition-all" onChange={(e) => setRuleData({...ruleData, expression: e.target.value})}/>
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-500 uppercase mb-2 block tracking-widest">Next Path</label>
                  <select className="w-full bg-slate-950 border border-slate-800 p-5 rounded-2xl outline-none focus:border-emerald-500 text-white appearance-none" onChange={(e) => setRuleData({...ruleData, nextStepId: e.target.value})}>
                    <option value="">End Workflow</option>
                    {steps.filter(s => s.id !== currentStep.id).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <button onClick={handleAddRule} className="w-full bg-emerald-500 text-slate-950 py-5 rounded-2xl font-black hover:bg-emerald-400 uppercase shadow-lg tracking-widest text-xs transition-all active:scale-95">Save Logic Rule</button>
              </div>
              <button onClick={() => setIsRuleModalOpen(false)} className="mt-4 w-full text-slate-500 text-[10px] font-black uppercase tracking-widest hover:text-white transition-colors">Cancel</button>
            </div>
          </div>
        )}

        {/* New Workflow Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 bg-black/95 flex justify-center items-center z-[200] p-4">
            <div className="bg-[#0f172a] p-10 rounded-[3rem] w-full max-w-md border border-slate-800 shadow-2xl">
              <h2 className="text-3xl font-black mb-8 italic text-emerald-400 uppercase tracking-tighter">NEW WORKFLOW</h2>
              <div className="space-y-4">
                <input type="text" placeholder="ID (UUID/Text)" className="w-full bg-slate-950 border border-slate-800 p-5 rounded-2xl text-white outline-none focus:border-blue-500 transition-all" value={newWorkflow.id} onChange={(e) => setNewWorkflow({...newWorkflow, id: e.target.value})}/>
                <input type="text" placeholder="Workflow Name" className="w-full bg-slate-950 border border-slate-800 p-5 rounded-2xl text-white outline-none focus:border-blue-500 transition-all" value={newWorkflow.name} onChange={(e) => setNewWorkflow({...newWorkflow, name: e.target.value})}/>
                <button onClick={handleCreateWorkflow} className="w-full bg-blue-600 hover:bg-blue-500 py-5 rounded-2xl font-black tracking-widest shadow-xl shadow-blue-900/30 active:scale-95 transition-all">INITIALIZE</button>
                <button onClick={() => setIsModalOpen(false)} className="w-full text-slate-500 text-[10px] font-black uppercase mt-4 tracking-widest text-center">Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;